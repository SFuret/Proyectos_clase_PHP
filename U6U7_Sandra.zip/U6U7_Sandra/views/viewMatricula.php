<main>
<?php
foreach($matriculas as $matricula){
    var_dump($matriculas);
    ?>
    
    <li><?php $matricula["nia"]?> </li>
    <li><?php $matricula["codigo"]?> </li>
    <li><?php $matricula["año"]?> </li>
    <?php
}

?>    

</main>